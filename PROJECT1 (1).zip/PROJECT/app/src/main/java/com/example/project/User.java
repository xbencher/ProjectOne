package com.example.project;



public class User {
    private String ptitle,dateofPurchase,Pdes,mrp,sp;

    public User() {
    }

    public User(String ptitle, String dateofPurchase, String pdes, String mrp, String sp) {
        this.ptitle = ptitle;
        this.dateofPurchase = dateofPurchase;
        Pdes = pdes;
        this.mrp = mrp;
        this.sp = sp;
    }

    public String getPtitle() {
        return ptitle;
    }

    public void setPtitle(String ptitle) {
        this.ptitle = ptitle;
    }

    public String getDateofPurchase() {
        return dateofPurchase;
    }

    public void setDateofPurchase(String dateofPurchase) {
        this.dateofPurchase = dateofPurchase;
    }

    public String getPdes() {
        return Pdes;
    }

    public void setPdes(String pdes) {
        Pdes = pdes;
    }

    public String getMrp() {
        return mrp;
    }

    public void setMrp(String mrp) {
        this.mrp = mrp;
    }

    public String getSp() {
        return sp;
    }

    public void setSp(String sp) {
        this.sp = sp;
    }
}
