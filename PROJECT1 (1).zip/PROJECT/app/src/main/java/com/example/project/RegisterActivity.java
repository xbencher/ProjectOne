package com.example.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
private TextInputLayout fname,lname,ucity,phone,email,pass;
private Button register;
    private FirebaseAuth mAuth;
   // private SharedPreferences sp;
    //private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
//sp=getSharedPreferences("project",MODE_PRIVATE);
//editor=sp.edit();
        setContentView(R.layout.activity_register);
        fname=findViewById(R.id.textInputLayout3);
        lname=findViewById(R.id.textInputLayout4);
        ucity=findViewById(R.id.textInputLayout5);
        phone=findViewById(R.id.textInputLayout6);
        email=findViewById(R.id.textInputLayout7);
        pass=findViewById(R.id.textInputLayout8);
        register=findViewById(R.id.button);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = email.getEditText().getText().toString();
                String password = pass.getEditText().getText().toString();

                mAuth.createUserWithEmailAndPassword(user, password)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(RegisterActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                /*String name=fname.getEditText().getText().toString();
                                intent.putExtra("name",name);
                                String city=ucity.getEditText().getText().toString();
                               intent.putExtra("city",city);
                                //editor.putString("city",city);
                                //editor.commit();
                                startActivity(intent);*/
                            } else {
                                Toast.makeText(RegisterActivity.this, "Failed ", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(RegisterActivity.this, "Failed " + e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

            }
        });

    }

    }

