package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SellActivity extends AppCompatActivity {
private TextInputLayout ptitle,dateofPurchase,Pdes,mrp,sp;
private Button add;
    private DatabaseReference dref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);
        ptitle=findViewById(R.id.textInputLayout3);
        dateofPurchase=findViewById(R.id.textInputLayout4);
        Pdes=findViewById(R.id.textInputLayout5);
        mrp=findViewById(R.id.textInputLayout6);
        sp=findViewById(R.id.textInputLayout7);

        dref= FirebaseDatabase.getInstance().getReference("user");

add.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        final String name=ptitle.getEditText().getText().toString();
        final String dop=dateofPurchase.getEditText().getText().toString();
        final String des=Pdes.getEditText().getText().toString();
        final String MRP=mrp.getEditText().getText().toString();
        final String sellingP=sp.getEditText().getText().toString();

        User p=new User(name,dop,des,MRP,sellingP);
        dref.push().setValue(p);
        Toast.makeText(SellActivity.this, "Record Saved", Toast.LENGTH_SHORT).show();
    }
});
    }
}