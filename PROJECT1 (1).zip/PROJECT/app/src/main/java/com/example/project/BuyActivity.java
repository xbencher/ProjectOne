package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BuyActivity extends AppCompatActivity {
private GridView gv;
    private DatabaseReference dref;
    private TextView tvname;
    private Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);
        gv = findViewById(R.id.gv);
        tvname = findViewById(R.id.gmail);
        spinner = findViewById(R.id.spinner);
        dref = FirebaseDatabase.getInstance().getReference("user");
        String city = getIntent().getStringExtra("city");
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<User> list = new ArrayList<User>();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    User p = ds.getValue(User.class);
                    list.add(p);
                }
                CustomAdapter adp = new CustomAdapter(list);
                gv.setAdapter(adp);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String UserCity=String.valueOf(spinner.getItemAtPosition(i));

            gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    if(UserCity.equalsIgnoreCase(city))
                    {
                        Intent intent=new Intent(BuyActivity.this,orderplaced.class);
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(BuyActivity.this, "You Can't Buy Items of another CITY", Toast.LENGTH_SHORT).show();

                }
            });
            //Toast.makeText(BuyActivity.this, "You Can Buy", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
});

    }
    class CustomAdapter extends BaseAdapter {
        private final List<User> list;
        public CustomAdapter(List<User> list) {
            this.list=list;
        }
        @Override
        public int getCount() {
            return list.size();
        }
        @Override
        public Object getItem(int i) {
            return list.get(i);
        }
        @Override
        public long getItemId(int i) {
            return 0;
        }
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            View vv=getLayoutInflater().inflate(R.layout.product_item,null,false);
            TextView title=vv.findViewById(R.id.textView2);
            TextView dop=vv.findViewById(R.id.textView3);
            TextView des=vv.findViewById(R.id.textView4);
            TextView mrp=vv.findViewById(R.id.textView5);
            TextView sp=vv.findViewById(R.id.textView6);
            User p=list.get(i);
            title.setText(p.getPtitle());
            dop.setText(p.getDateofPurchase());
            des.setText(p.getPdes());
            mrp.setText("Rs. "+p.getMrp());
            sp.setText("Rs. "+p.getSp());
            return vv;
        }

    }

    }
